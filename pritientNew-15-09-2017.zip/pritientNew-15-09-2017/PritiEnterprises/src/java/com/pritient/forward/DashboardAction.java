/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.pritient.forward;

import com.opensymphony.xwork2.ActionSupport;

/**
 *
 * @author nishant.vibhute
 */
public class DashboardAction extends ActionSupport {

    public String execute() throws Exception {
        return ActionSupport.SUCCESS;
    }

}
